/** Mounted-files dashboard: progress bars, search, sort, net savings + a rough
 * CNY figure (plan items 16 + 17), matching the DSH tab styling. */
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
export type MountedFilesViewProps = ConvViewProps & PropsLocale<'file-mount'>;
/**
 * Pure reader over the conversation snapshot: fold the injected mount
 * messages once per snapshot revision, then render one dashboard row per
 * file with a progress bar, search, and sorting.
 * @param props - slot standard kit (useSession) plus the view locale seat.
 * @returns the mounted-files dashboard, or the localized empty hint.
 */
export declare function MountedFilesView({ useSession, t }: MountedFilesViewProps): import("react").JSX.Element;
//# sourceMappingURL=MountedFilesView.d.ts.map