/**
 * Browser half of dsh-file-mount: contributes the Mounted Files tab to the
 * conversation view ring. The trajectory tab and the conversation context
 * rows need no code here — the harness projects the plugin-injected
 * messages onto them from their standard sources.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Required services: the slot registry and the locale service. */
export declare const inject: string[];
/** Client plugin name (bundle diagnostics). */
export declare const name = "file-mount-ui";
/**
 * Register the Mounted Files tab. The registration rides the slot
 * service's effect wrapper, so plugin unload removes the tab.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map