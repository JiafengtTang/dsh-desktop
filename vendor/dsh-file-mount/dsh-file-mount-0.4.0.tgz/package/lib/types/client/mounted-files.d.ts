/**
 * Pure client-side fold of the mount ledger: one entry per mounted file,
 * upserted from the plugin-injected context messages in conversation-node
 * order. The host's structured message source is the durable carrier, so
 * this fold works live and on resumed history alike. Validation and the
 * merge rule come from mount-source.ts — the SAME rule the host replays
 * with (plan item 20).
 *
 * Freshness (attention-decay plan): assistant nodes expose per-request usage
 * (input tokens), so the fold also derives the current context length; each
 * segment's `born` position then maps to a display level (fresh/ok/warn/
 * expired/unknown) via the threshold the host stamped on the source.
 */
import type { ConversationNode } from '@deepseek-ai/dsh-client-runtime/client';
import type { LedgerSegment } from '../types.ts';
/** One mounted file as the view presents it. */
export interface MountedFileView {
    /** Normalized absolute path (ledger identity). */
    path: string;
    /** Short (8-char) content hash for the identity column. */
    hash: string;
    /** Line count of the file at hash time. */
    totalLines: number;
    /** Mounted ranges, normalized ascending, with freshness metadata. */
    ranges: LedgerSegment[];
    /** How the ledger changed last. */
    mountKind: 'new' | 'increment' | 'remount' | 'dedup';
    /** Cumulative tokens kept out of the context for this path. */
    savedTokens: number;
    /** Cumulative tokens the plugin's own notes cost for this path. */
    spentTokens: number;
    /** Source message seq (stable ordering). */
    seq: number;
    /** Current context length (latest request input tokens), for freshness. */
    contextL?: number;
    /** Freshness expiry threshold the host configured (default 0.85). */
    freshnessThreshold: number;
}
/** Display levels for one segment's freshness. */
export type FreshnessLevel = 'fresh' | 'ok' | 'warn' | 'expired' | 'unknown';
/**
 * Freshness level from the attention-decay drift model: r = (L - born) / L
 * is how far the segment has drifted from the context tail (fresh = tail
 * attention zone, > threshold = pushed past the head zone = expired).
 */
export declare function freshnessLevel(born: number | undefined, contextL: number | undefined, threshold?: number): FreshnessLevel;
/**
 * Fold conversation nodes into the mounted-file list. Foreign or malformed
 * nodes are skipped; a hash change replaces the entry wholesale (the old
 * mount is stale), same-hash messages union their ranges. The latest
 * assistant usage sets the context length every view carries for freshness.
 */
export declare function foldMounts(nodes: readonly ConversationNode[]): MountedFileView[];
//# sourceMappingURL=mounted-files.d.ts.map