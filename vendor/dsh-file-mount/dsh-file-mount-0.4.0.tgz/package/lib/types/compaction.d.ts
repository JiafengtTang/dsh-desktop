/**
 * Compaction awareness for the mount ledger (duck-typed against DSH's
 * canonical checkpoint shape, so the plugin needs no dsh-compaction peer).
 *
 * DSH compacts a session at the SURFACE layer: one `user/message` checkpoint
 * (canonical source `{ kind: 'plugin', plugin: 'compact' }`) replaces the
 * shadowed range, and its event-level `sourceEventSeqs` lists every shadowed
 * event. Shadowed events stay in the raw log, so a ledger that folds the log
 * must skip them: a mount claim from a shadowed message no longer holds,
 * because the model context no longer contains that content. Deduping against
 * a shadowed claim would silently deny the model content it no longer has.
 */
/**
 * True when an event is the canonical compaction checkpoint: a
 * `user/message` whose source is the plugin 'compact' marker.
 */
export declare function isCompactCheckpoint(event: unknown): boolean;
/**
 * Seq numbers of every event shadowed by a compact checkpoint in the log
 * (union over all checkpoints). Malformed lists and non-integer entries are
 * skipped defensively.
 */
export declare function shadowedSeqsOf(events: readonly unknown[]): Set<number>;
//# sourceMappingURL=compaction.d.ts.map