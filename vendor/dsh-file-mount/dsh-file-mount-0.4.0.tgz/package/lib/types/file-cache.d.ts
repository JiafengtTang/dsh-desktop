import { readFile, stat } from 'node:fs/promises';
/**
 * Verified file-content cache: disk is the single source of truth, this
 * module is the ledger's only read path for file identity.
 *
 * Invariants:
 * - lookup() stats first (bigint); a cache hit needs mtime+size equality AND
 *   TTL freshness, and returns the SAME entry object (reference identity is
 *   the public fast-path signal).
 * - The recorded stat is the PRE-READ stat: concurrent double reads cannot
 *   poison the cache, an overwritten read only forces the next miss.
 * - TTL is the safety valve for content changed under an unchanged mtime+size
 *   (e.g. git restoring timestamps): after expiry the entry re-reads once.
 * - Pinned entries (mounted files) skip capacity eviction; pins are
 *   reference-counted per session key so one teardown never drops another
 *   session's pin. Bigint values stay in memory only (JSON cannot serialize
 *   them).
 * - Concurrent reads of the same path merge onto one in-flight read, so the
 *   file is read once and every caller shares the result.
 * - Entries carry per-line fingerprints (the draft) for incremental
 *   remounting; files over the size cap keep no fingerprints and fall back
 *   to a whole-window remount.
 */
/** One cached identity record for a file. */
export interface FileCacheEntry {
    /** Pre-read stat mtime in nanoseconds. */
    mtimeNs: bigint;
    /** Pre-read stat byte size. */
    size: bigint;
    /** sha256 hex of the raw bytes. */
    hash: string;
    /** Per-line fingerprints in line order (index 0 = line 1); empty when capped. */
    lineHashes: string[];
    /** lineHashes.length (0 when the draft was skipped). */
    lineCount: number;
}
/**
 * One verified identity read: the current entry plus, when the on-disk
 * content changed since the cache last saw it, the previous entry.
 * previous is the draft item 9 diffs against; callers must confirm its
 * hash matches their ledger before diffing.
 */
export interface CacheLookup {
    current: FileCacheEntry;
    previous?: FileCacheEntry;
    /** True when the content changed (current.hash !== previous.hash). */
    changed: boolean;
}
/** Injectables kept narrow for deterministic tests. */
export interface FileCacheOptions {
    capacity?: number;
    ttlMs?: number;
    /** Files larger than this keep no line fingerprints (whole-window remount). */
    maxFingerprintBytes?: number;
    /** Files larger than this are not managed at all (never read or cached). */
    maxManagedBytes?: number;
    readFile?: typeof readFile;
    stat?: typeof stat;
}
export declare class FileContentCache {
    private byPath;
    /** Mounted-file pins: path -> the session keys currently pinning it. */
    private pinned;
    /** In-flight reads by path: concurrent lookups share one read. */
    private inFlight;
    private readonly capacity;
    private readonly ttlMs;
    private readonly maxFingerprintBytes;
    private readonly maxManagedBytes;
    private readonly readFile;
    private readonly stat;
    constructor(opts?: FileCacheOptions);
    /** Pin a mounted file under a session key (idempotent per key). */
    pin(absPath: string, key: string): void;
    /** Release one session's pin; the entry becomes evictable at zero pins. */
    unpin(absPath: string, key: string): void;
    /** Release every pin a session holds (session teardown / refold). */
    unpinAll(key: string): void;
    /** Forget one path's cached identity (write/edit/forget callers). */
    invalidate(absPath: string): void;
    /**
     * Verified identity read: stat match within TTL returns the cached entry
     * with zero disk reads; otherwise read + hash + refresh, returning the
     * previous entry when the content changed. Returns null when the file
     * cannot be stat'ed or read (caller passes through natively).
     */
    lookup(absPath: string): Promise<CacheLookup | null>;
    /** Legacy single-entry view (current entry only). */
    get(absPath: string): Promise<FileCacheEntry | null>;
    /** Build the identity + draft for one freshly-read buffer. */
    private buildEntry;
    /** Evict the least-recently-verified unpinned entry when over capacity. */
    private evict;
}
//# sourceMappingURL=file-cache.d.ts.map