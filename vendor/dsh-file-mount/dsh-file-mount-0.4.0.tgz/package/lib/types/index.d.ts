/**
 * dsh-file-mount host half: incremental file mounting with read dedupe.
 *
 * One post-execute interception point owns the whole model-facing surface:
 * after a successful text `read`, the plugin verifies the file identity
 * (stat-verified cache), folds the returned window against the per-session
 * mount ledger, and returns a PostToolDecision that (a) replaces the result
 * content with a short marker when the window adds nothing new, and (b)
 * injects the new ranges as plugin-sourced additionalContexts. The canonical
 * tool value is preserved throughout, so UI read cards and the audit log
 * stay intact.
 *
 * The ledger's durable carrier is the injected message SOURCE (structured,
 * merge-extensible JSON on a standard `user/message` event), so resumed
 * sessions and the browser client fold state from persistence-safe events.
 *
 * Compaction-aware: mount messages shadowed by a compact checkpoint no longer
 * count as mounted (their content has left the model context) — both when the
 * live log gains a checkpoint and when a resumed session replays the log.
 *
 * @module dsh-file-mount
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { MountedFile } from './types.ts';
export { FileContentCache } from './file-cache.ts';
export { MountStore, type LedgerRecord } from './store.ts';
export { normalize, subtract, clamp, type LineRange } from './ranges.ts';
export { hashBuffer } from './hash.ts';
export { normalizeAbsPath } from './paths.ts';
export { formatRange, markerHead, renderDedupMarker, renderMountBlock, renderRemountMarker, } from './render.ts';
export type { MountedFile, MountKind, MountSource, Segment } from './types.ts';
/** Plugin config: ledger limits and the global kill switch. */
export interface Config {
    /** Master switch; disabled keeps every read native. */
    enabled?: boolean;
    /** File identity cache capacity (pinned mounts exempt). */
    capacity?: number;
    /** File identity cache TTL (safety valve, ms). */
    ttlMs?: number;
    /** Per-session mounted-file pin cap (bounds the identity cache). */
    maxPinnedFiles?: number;
    /** Minimum token saving before a dedup is worth the marker overhead. */
    minSavedTokens?: number;
    /** Files larger than this keep no line fingerprints (whole-window remount). */
    maxFingerprintBytes?: number;
    /** Glob patterns of paths the plugin never manages (e.g. node_modules). */
    excludeGlobs?: string[];
    /** Files larger than this are not managed at all (never read or cached). */
    maxManagedBytes?: number;
    /** Optional path of the cross-session stats file (plan item 24). */
    statsFile?: string;
    /** Freshness tracking (attention-decay plan): segments drift from the context tail. */
    freshnessEnabled?: boolean;
    /** Drift ratio past which a segment counts as expired (0..1, 0.85 = top 15%). */
    freshnessThreshold?: number;
}
export declare const Config: z<Config>;
export declare const name = "file-mount";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Live mount service: per-session ledgers plus the shared file cache. */
        fileMount: FileMountService;
    }
}
/**
 * Host service: per-session mount ledgers, the stat-verified file identity
 * cache, and resume replay from injected message sources.
 */
export declare class FileMountService extends Service {
    static inject: string[];
    private readonly enabled;
    private readonly maxPinnedFiles;
    private readonly minSavedTokens;
    private readonly cache;
    private readonly stores;
    private readonly restores;
    /** Log length each agent's ledger has folded up to (live checkpoint sweep). */
    private readonly cursors;
    /** Per-session pin LRU: agent id -> mounted paths, most recent last. */
    private readonly pinOrders;
    /** Emit the incompatible-read warning at most once per process. */
    private compatWarned;
    /** Per-session silent-dedup savings waiting to ride the next real message. */
    private readonly pendingDedup;
    /** Per-session current context length (latest request input tokens, from usage). */
    private readonly contextL;
    private readonly excludeGlobs;
    private readonly statsFile;
    private readonly freshnessEnabled;
    private readonly freshnessThreshold;
    constructor(ctx: Context, config?: Config);
    /** Fold one successful read into the ledger and reshape the decision. */
    private onReadResult;
    /** Register the model-facing "return the book" tool (plan item 25). */
    private registerForgetTool;
    /** A write puts the full new content into the model's context, so mount the
     * file as already known: the next read dedupes instead of re-sending (plan
     * item 13). The cache identity is invalidated first so no stale draft
     * survives the write. */
    private onWriteResult;
    /** An edit changes only a region, so the whole file is NOT known: just
     * invalidate the cache identity; the next read diff-remounts (plan item 9). */
    private onEditResult;
    /** Take (and clear) the silent-dedup savings pending for a session+file, so
     * they ride the next real message and resume reconstruction stays exact. */
    private takePendingSaved;
    /** Serializes stats-file merges so concurrent disposals cannot lose totals. */
    private statsWrite;
    /** Cross-session ledger (plan item 24): merge one store's totals into the
     * configured stats file (atomic tmp + rename; never throws). */
    private persistStats;
    /** Persist every live store at service shutdown (reliable cross-session
     * totals even though agent/disposed may not precede plugin disposal). */
    private persistAllStats;
    /** Cross-session totals from the stats file (or null when unavailable). */
    stats(): Promise<{
        sessions: number;
        savedTokens: number;
        spentTokens: number;
    } | null>;
    /** Decision body after the cheap guards, isolated so it can never throw out. */
    private onReadResultInner;
    /** The structured source state for one injected message. */
    private mountSource;
    /** One-line account of a mount (collapsed context-row summary). */
    private mountSummary;
    /** The plugin-sourced context message carrying one mount block. */
    private contextMessage;
    /** Record segments and pin the identity in the file cache for one session. */
    private mount;
    /** Context position (input tokens) a fresh mount will occupy: the last
     * request's total plus this block's estimate. Undefined when the session has
     * no usage data (the segment then renders as unknown freshness). */
    private bornAt;
    /** Stamp fresh-born metadata on newly mounted ranges (same mount position). */
    private stampBorn;
    /** Pin a mounted file for one session, honoring the per-session cap (LRU). */
    private pinFor;
    /** Reconcile the cache pins with one session's current ledger. */
    private resyncPins;
    /** Drop one session's in-memory ledger and cache pins (session teardown). */
    private disposeLedger;
    /** One-time warning when the read result shape is no longer recognized. */
    private warnIncompat;
    /** Per-session ledger, restored lazily on first access (resume race guard). */
    private storeFor;
    /**
     * Mount records whose claims still hold: file-mount messages that no compact
     * checkpoint shadows. Shadowed messages stay in the raw log, but their
     * content has left the model context, so folding them would resurrect
     * stale claims (and enable false dedup).
     */
    private visibleMountRecords;
    /**
     * Fold the live log tail for new compact checkpoints (DSH does not emit a
     * session-start 'compact' notification yet). Any new checkpoint — or a
     * replaced/shrunk log — re-derives the ledger from the still-visible mount
     * messages, so a claim never outlives the content it cites.
     */
    private sweep;
    /** Update the per-session context length from one assistant/message usage. */
    private trackContextLength;
    /** Re-derive the ledger from the still-visible mount messages. */
    private refold;
    /** Replay the ledger from plugin-injected message sources in the live log. */
    private kickoffRestore;
    /** Forget the ledger (clear/compact): the context guarantee is gone. */
    private resetLedger;
    /** Live ledger snapshot for UIs and tests. */
    ledger(agent: Agent): MountedFile[];
}
/**
 * Register the file-mount service (the interception listener lives on the
 * service fiber so its lifecycle rides the plugin's disposal).
 * @param ctx - host context.
 * @param config - plugin config after Loader validation.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map