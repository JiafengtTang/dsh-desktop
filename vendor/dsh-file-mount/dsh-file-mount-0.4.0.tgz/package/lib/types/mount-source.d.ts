/**
 * The ONE ledger rule shared by the host half (MountStore.replay) and the
 * browser half (foldMounts): source validation + the same-hash-unions /
 * hash-change-replaces merge. Editing the fold semantics here edits both
 * halves at once (plan item 20).
 *
 * Freshness (attention-decay plan): each segment carries `born` (context
 * position in input tokens at mount time) and `expired` (how many times the
 * content expired and was re-read). The merge rules are: same hash unions
 * segments (adjacent merge keeps the EARLIEST born and the MAX expired), a
 * hash change replaces the entry wholesale; expired segments are pruned off
 * the ledger by the host (they stop deduping) and their count moves into the
 * per-file history so a re-mount inherits it.
 */
import type { ExpiredSegment, LedgerSegment, MountKind } from './types.ts';
/**
 * Normalize ledger segments: sort ascending, merge overlapping/touching
 * ranges, carrying freshness metadata across merges (earliest born wins,
 * expired counts add up to the max).
 */
export declare function normalizeLedger(segments: readonly LedgerSegment[]): LedgerSegment[];
/** What one mount message adds to the ledger (post-validation). */
export interface MountDelta {
    hash: string;
    totalLines: number;
    segments: LedgerSegment[];
    savedTokens: number;
    spentTokens: number;
}
/** A validated file-mount source: the identity plus the delta it carries. */
export interface ParsedMountSource {
    path: string;
    mountKind: MountKind;
    delta: MountDelta;
}
/**
 * Validate a file-mount source (the injected message's structured source).
 * Returns undefined for foreign or malformed shapes, so a foreign log never
 * breaks the ledger. Segments without freshness fields (pre-freshness
 * messages) fold with born undefined and expired 0.
 */
export declare function parseMountSource(source: unknown): ParsedMountSource | undefined;
/** Fold state shared by the host ledger and the browser view. */
export interface MountState {
    hash: string;
    totalLines: number;
    segments: LedgerSegment[];
    savedTokens: number;
    spentTokens: number;
}
/**
 * The fold rule: same hash unions segments and accumulates tokens; a hash
 * change replaces the entry wholesale (the old mount is stale) while the
 * cumulative totals survive.
 */
export declare function applyMountState(existing: MountState | undefined, delta: MountDelta): MountState;
/** Result of pruning expired segments off the ledger. */
export interface PruneResult {
    /** Segments that are still fresh (kept on the ledger). */
    active: LedgerSegment[];
    /** The expired ones with their count bumped (moved to per-file history). */
    history: ExpiredSegment[];
}
/**
 * Lazy freshness check (attention-decay plan): a segment is expired when its
 * drift from the context tail passes the threshold — r = (L - born) / L with
 * L the current context length (latest request input tokens). Expired
 * segments leave the ledger (they stop deduping; the next read re-sends them)
 * and their expired count moves into the history. Segments without a born
 * (no usage data yet, or pre-freshness messages) are never pruned.
 */
export declare function pruneExpired(segments: readonly LedgerSegment[], contextL: number | undefined, threshold: number): PruneResult;
/**
 * Let freshly mounted segments inherit the expired count of overlapping
 * history entries (the content was re-read after expiring), then drop those
 * history entries (the range is fresh again). Overlaps are counted once per
 * history item (max across all overlapping items wins for every new segment).
 */
export declare function inheritHistory(segments: readonly LedgerSegment[], history: readonly ExpiredSegment[]): {
    segments: LedgerSegment[];
    history: ExpiredSegment[];
};
//# sourceMappingURL=mount-source.d.ts.map