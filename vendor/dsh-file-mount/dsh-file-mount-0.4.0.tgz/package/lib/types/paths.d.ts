/**
 * Canonical identity for mounted files: absolute, symlink-resolved (a soft
 * link unifies to its real file), and case-folded on case-insensitive
 * filesystems so `SRC/Foo.TS` and `src/foo.ts` share one ledger entry
 * (plan item 22).
 */
export declare function normalizeAbsPath(absPath: string): string;
//# sourceMappingURL=paths.d.ts.map