/**
 * Line-range set arithmetic for the mount ledger (ported from piwpi's
 * context-mount ranges.ts). Pure functions over 1-based inclusive intervals;
 * every returned array is a fresh, normalized (sorted, merged, non-adjacent)
 * range list. The ledger calls these to answer "which part of this read is
 * NOT already in the model context".
 */
export type LineRange = {
    start: number;
    end: number;
};
/** Sort and merge overlapping or touching ranges ([20,40]+[41,60] -> [20,60]). */
export declare function normalize(ranges: LineRange[]): LineRange[];
/**
 * Parts of `want` not covered by `have` (ascending, non-adjacent). `have` is
 * normalized first so overlapping or touching mounted ranges merge correctly.
 */
export declare function subtract(have: LineRange[], want: LineRange): LineRange[];
/**
 * Truncate a range to a file that shrank to maxEnd lines. Returns null when
 * the range lies entirely past the file (or the file is empty).
 */
export declare function clamp(r: LineRange, maxEnd: number): LineRange | null;
//# sourceMappingURL=ranges.d.ts.map