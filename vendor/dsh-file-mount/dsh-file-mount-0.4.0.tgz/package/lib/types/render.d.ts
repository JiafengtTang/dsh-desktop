import type { Segment } from './types.ts';
export declare function formatRange(start: number, end: number): string;
/**
 * Shared marker head: identity + short hash + a compact mounted summary.
 * A few ranges are listed outright; many ranges collapse to a line/range
 * count so the note never grows with the number of mounted ranges (item 12).
 */
export declare function markerHead(path: string, hash: string, mounted: Segment[]): string;
/** Full-coverage read: the window adds nothing new. */
export declare function renderDedupMarker(path: string, hash: string, mounted: Segment[]): string;
/** Line counts a diff produced (added/removed/unchanged), for the remount note. */
export interface RemountStats {
    added: number;
    removed: number;
    unchanged: number;
}
/** Hash change: the previous mount is stale and the window remounts. With diff
 * stats, report the change shape; otherwise the generic remount note. */
export declare function renderRemountMarker(path: string, hash: string, mounted: Segment[], stats?: RemountStats): string;
/** Options for {@link renderMountBlock}. */
export interface MountBlockOptions {
    /** Mounted identity (path as shown to the model). */
    path: string;
    /** Current full-file hash. */
    hash: string;
    /** Ledger state AFTER this mount lands. */
    mounted: Segment[];
    /** 1-based line number of `lines[0]` in the file. */
    windowStart: number;
    /** The read tool's returned window body, in order. */
    lines: string[];
    /** Ranges of `lines` that are NOT yet in the context (normalized, in-window). */
    missing: Segment[];
}
/** Render the new-content block: marker head + one header/body pair per missing range. */
export declare function renderMountBlock(opts: MountBlockOptions): string;
//# sourceMappingURL=render.d.ts.map